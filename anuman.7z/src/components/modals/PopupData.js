export const modalTitle = {
    adminDelete: "Delete Admin",
  };
  export const modalBody = {
    deleteAdmin:"Are you sure you want to delete this Admin?",
    deleteCategory:"Are you sure you want to delete this Category?",
    deleteQuestion:"Are you sure you want to delete this Question?",
    deleteRole:"Are you sure you want to Block/Unblock this Role?"
  };
  