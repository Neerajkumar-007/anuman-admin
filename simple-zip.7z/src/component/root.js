import React from "react";
const Root=()=>{
    const data = [
        {
          date: "10-08-2023",
          title: "Text1",
        },
        {
          date: "10-08-2023",
          title: "Text2",
        },
        {
          date: "09-08-2023",
          title: "Text3",
        },
        {
          date: "07-08-2023",
          title: "Text5",
        },
        {
          date: "07-08-2023",
          title: "Text4",
        },
      ];
    
      // const finalData = {
      //   '10-08-2023': ['Text1','Text2'] ,
      //     '09-08-2023': ['Text3'] ,
      //     '07-08-2023': ['Text4','Text5'] ,
      // }
    
      let finalData = {};
      data.map((item) => {
        if (!finalData[item.date]) {
          finalData[item.date] = [item.title];
        } else {
          finalData[item.date].push(item.title);
        }
      });
    
      console.log({ finalData });
    return(
        <div>
            <h1>thhis is home</h1>
        </div>
    )

}
export default Root;