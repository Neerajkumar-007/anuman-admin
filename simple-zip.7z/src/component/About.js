import React, { useState } from "react";
var Colors = ["red", "green", "blue", "orange", "yellow"];
const About=()=>{
    const [count,setCount]=useState(0)
    const [color, setColor] = useState(Colors);

    const handlehdfhd = (e) => {
      e.preventDefault();
      setColor(Colors[Math.floor(Math.random() * Colors.length)]);
    };

    const style = {
        backgroundColor: color,
      };
    return(
        <div style={style}>
            
            {count}
            <button onClick={(e)=>{handlehdfhd(e);setCount(count+1)}}>plus</button>
            <button onClick={(e)=>{handlehdfhd(e);setCount(count*2)}}>Multiply</button>
            <button onClick={(e)=>{handlehdfhd(e);setCount(count/2)}}>Divide</button>
            <h1>thhis is About</h1>
        </div>
    )

}
export default About;