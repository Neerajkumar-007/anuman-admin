import React from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const Navbar = () => {
    let Nevigate=useNavigate();
    const GoAbout=()=>{
        Nevigate('/about')
    }
    const GoHome=()=>{
        Nevigate('/home')
    }
    
    const GoContact=()=>{
        Nevigate('/contact')
    }
  return (
    <div>
      <div style={{ backgroundColor:'aqua'}}>
        <ul className="ul">
         <li onClick={GoHome}>home</li>
         <li onClick={GoAbout}>about</li>
         <li onClick={GoContact}>contact</li>
        </ul>
        <main>
        <Link to="/home"></Link>
          <Link to="/about"></Link>
          <Link to="/contact"></Link>
        </main>
      </div>
      <div>


      </div>
    </div>
    
  );
};
export default Navbar;
