import React from "react";
const Contact=()=>{
    return(
        <div>
            <h1>thhis is contact</h1>
            <a><button> this</button></a>
        </div>
         
    )

}
export default Contact;