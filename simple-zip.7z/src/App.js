import React, { useState } from "react";
// import "./styles.css";
// import { GoogleLogin, GoogleLogout } from "react-google-login";
import { GoogleOAuthProvider } from '@react-oauth/google';
import { GoogleLogin } from '@react-oauth/google';
import jwt_decode from "jwt-decode"
function App() {
  // const [name, setName] = useState("");
  // const [email, setEmail] = useState("");
  // const [url, setUrl] = useState("");
  // const [loginStatus, setLoginStatus] = useState(false);

  // const responseGoogle = response => {
  //   console.log(response);
  //   setName(response.profileObj.name);
  //   setEmail(response.profileObj.email);
  //   setUrl(response.profileObj.imageUrl);
  //   setLoginStatus(true);
  // };
  // const logout = () => {
  //   console.log("logout");
  //   setLoginStatus(false);
  // };
  // const responseGoogle = (response) => {
  //   console.log(response);
  // }

  return <div>
      <GoogleOAuthProvider clientId="924416825888-od4kcmsrt97s6vutm87k2u0eipa1thvu.apps.googleusercontent.com">
      <GoogleLogin
    onSuccess={credentialResponse => {
      const data=jwt_decode(credentialResponse.credential)
      console.log(credentialResponse,data);
    }}
    onError={() => {
      console.log('Login Failed');
    }}
  />
        </GoogleOAuthProvider>
      {/* <GoogleLogin
    clientId="404537245746-rjqcdof4pcsd6apkcbg4ict8e3tisq43.apps.googleusercontent.com"
    buttonText="Login"
    onSuccess={responseGoogle}
    onFailure={responseGoogle}
    cookiePolicy={'single_host_origin'}
  /> */}
  {/* <div className="App">
      <h1>Login with Google</h1>
      {!loginStatus && (
        <GoogleLogin
          clientId="404537245746-rjqcdof4pcsd6apkcbg4ict8e3tisq43.apps.googleusercontent.com"
          buttonText="Login"
          onSuccess={responseGoogle}
          onFailure={responseGoogle}
          cookiePolicy={"single_host_origin"}
        />
      )}
      {loginStatus && (
        <div>
          <h2>Welcome {name}</h2>
          <h2>Email: {email}</h2>
          <img src={url} alt={name} />
          <br />
          <GoogleLogout
            clientId="671348139606-906f7lcl8vk6l26hivc1ka0hk2teuvb1.apps.googleusercontent.com"
            buttonText="Logout"
            onLogoutSuccess={logout}
          />
        </div>
      )}
    </div> */}
  </div>
}

export default App;

