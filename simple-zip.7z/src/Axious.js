import axios from "axios"
import React, { useEffect, useState } from "react"

const Axious =() => {
    const [users, setUsers] = useState([])
    const [isLoading, setIsLoading] = useState(false)
    const fetchData = (e) => {
      const query=e.target.value;
      setIsLoading(true)
      axios
        .get(`https://jsonplaceholder.typicode.com/users?q=${query}`)
        .then(response => {
          setUsers(response.data)
          setIsLoading(false)
        })
    }
    // useEffect(() => {
    //     fetchData()
    //   }, [])

    return (
        <div style={{textAlign:'center'}}>
          <div>
          <h2>search user by name</h2>
        <input onChange={fetchData} label="Search User" />
          </div>
        <button onClick={fetchData}>Click Me</button>
                 <div>
                   {isLoading && <p>Loading...</p>}
                   {users.map(item => (
              <div key={item.id}>{item.name}</div>
              ))}

        </div>
        </div>
    )
}

export default Axious;